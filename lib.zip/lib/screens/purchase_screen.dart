// lib/screens/purchase_screen.dart
//
// CHANGELOG (this revision):
// 1. Purchase history cards now lazy-load full item detail (with spec
//    label + image) the first time they're expanded, because GET
//    /purchases (list) does not return `items` — only GET /purchases/{id}
//    (detail) does. Previously every card showed "no items" even when the
//    purchase had items.
// 2. Two items with the same product name but different RAM/storage
//    (e.g. "kok" 32GB/1TB vs "kok" 32GB/512GB) are now distinguishable —
//    each row shows its spec label, product code, and thumbnail.
// 3. The option picker (multi-variant product tap) is now a full screen
//    instead of a small bottom sheet, so long option lists aren't cramped.
// 4. Cart quantity is no longer +/- only — tapping the number opens a
//    small dialog to type an exact quantity directly.
// 5. Image field fixed to read PurchaseItemModel.imageUrl (mapped from the
//    API's "image" key) consistently everywhere a purchase item is shown.

import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/models.dart';
import '../providers/purchase_provider.dart';
import '../providers/supplier_provider.dart';
import '../providers/product_provider.dart';
import '../theme/app_theme.dart';
import '../utils/formatter.dart';
import '../utils/image_helper.dart';
import '../widgets/common_widgets.dart';
import 'product_screen.dart' show scanBarcode;
import '../services/api_service.dart';
import '../utils/pos_report_helper.dart';

// ══════════════════════════════════════════════════════════════════════════════
//  PURCHASE LIST SCREEN
// ══════════════════════════════════════════════════════════════════════════════
class PurchaseScreen extends StatefulWidget {
  const PurchaseScreen({super.key});
  @override
  State<PurchaseScreen> createState() => _PurchaseScreenState();
}

class _PurchaseScreenState extends State<PurchaseScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PurchaseProvider>().load();
      context.read<SupplierProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('ការទិញ'),
        actions: [
          IconButton(
            icon: const Icon(Icons.bar_chart_rounded, color: Colors.white),
            tooltip: 'របាយការណ៍ការទិញ',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const _PurchaseReportModal())),
          ),
          IconButton(
            icon: const Icon(Icons.add, color: Colors.white),
            tooltip: 'New Purchase',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const _CreatePurchaseScreen())),
          ),
        ],
      ),
      body: Consumer<PurchaseProvider>(
        builder: (_, prov, __) => prov.isLoading
            ? const AppLoading()
            : prov.purchases.isEmpty
            ? EmptyState(
          message: 'រកមិនឃើញការទិញ',
          icon: Icons.shopping_bag_outlined,
          action: 'ការទិញថ្មី',
          onAction: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const _CreatePurchaseScreen())),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: prov.purchases.length,
          itemBuilder: (_, i) => _PurchaseCard(purchase: prov.purchases[i]),
        ),
      ),
    );
  }
}

class _PurchaseCard extends StatefulWidget {
  final PurchaseModel purchase;
  const _PurchaseCard({required this.purchase});

  @override
  State<_PurchaseCard> createState() => _PurchaseCardState();
}

class _PurchaseCardState extends State<_PurchaseCard> {
  // Detail (with items) is loaded lazily on first expand, since the list
  // endpoint doesn't include items. Cached locally so re-collapsing /
  // re-expanding doesn't re-fetch.
  List<PurchaseItemModel>? _items;
  bool _loadingItems = false;
  bool _loadFailed = false;

  Future<void> _loadItemsIfNeeded() async {
    if (_items != null || _loadingItems) return;
    // If the list response already happened to include items, use them.
    if (widget.purchase.items.isNotEmpty) {
      setState(() => _items = widget.purchase.items);
      return;
    }
    setState(() {
      _loadingItems = true;
      _loadFailed = false;
    });
    final detail = await context.read<PurchaseProvider>().fetchDetail(widget.purchase.id);
    if (!mounted) return;
    setState(() {
      _loadingItems = false;
      if (detail != null) {
        _items = detail.items;
      } else {
        _loadFailed = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final purchase = widget.purchase;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: ExpansionTile(
        onExpansionChanged: (open) {
          if (open) _loadItemsIfNeeded();
        },
        tilePadding: const EdgeInsets.fromLTRB(14, 8, 16, 8),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        collapsedShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        // Leading icon — rounded square matching screenshot 1
        leading: Container(
          width: 46, height: 46,
          decoration: BoxDecoration(
              color: AppTheme.primaryLt,
              borderRadius: BorderRadius.circular(12)),
          child: const Icon(Icons.shopping_bag_outlined, color: AppTheme.primary, size: 22),
        ),
        // Title: #ID
        title: Text(
          '#${purchase.id}',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15,
              color: AppTheme.textDark),
        ),
        // Subtitle: supplier · date (+ note)
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 2),
            Row(children: [
              Text(purchase.supplierName ?? '—',
                  style: const TextStyle(fontSize: 12, color: AppTheme.textGrey)),
              const Text('  ·  ',
                  style: TextStyle(fontSize: 12, color: AppTheme.textMuted)),
              Text(Formatter.date(purchase.createdAt),
                  style: const TextStyle(fontSize: 12, color: AppTheme.textGrey)),
            ]),
            if ((purchase.note ?? '').trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(
                  purchase.note!.trim(),
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11,
                      fontStyle: FontStyle.italic, color: AppTheme.textGrey),
                ),
              ),
          ],
        ),
        // Amount right-aligned in primary colour
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(Formatter.currency(purchase.totalAmount),
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 16,
                    color: AppTheme.primary)),
          ],
        ),
        children: [
          const Divider(height: 1, color: AppTheme.border),
          const SizedBox(height: 8),
          _buildItemsSection(),
        ],
      ),
    );
  }

  Widget _buildItemsSection() {
    if (_loadingItems) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Center(
          child: SizedBox(
            width: 22, height: 22,
            child: CircularProgressIndicator(strokeWidth: 2.4, color: AppTheme.primary),
          ),
        ),
      );
    }
    if (_loadFailed) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(children: [
          const Expanded(
            child: Text('មិនអាចទាញយកធាតុបានទេ',
                style: TextStyle(color: AppTheme.danger, fontSize: 12)),
          ),
          TextButton(
            onPressed: _loadItemsIfNeeded,
            child: const Text('ព្យាយាមម្ដងទៀត', style: TextStyle(fontSize: 12)),
          ),
        ]),
      );
    }
    final items = _items ?? const <PurchaseItemModel>[];
    if (items.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 10),
        child: Center(child: Text('មិនមានធាតុ',
            style: TextStyle(color: AppTheme.textGrey, fontSize: 12))),
      );
    }
    return Column(
      children: items.map((item) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              width: 42, height: 42,
              child: _PurchaseProdImg(url: item.imageUrl),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.productName,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                if (item.specLabel.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(item.specLabel,
                        style: const TextStyle(fontSize: 11, color: AppTheme.primary)),
                  ),
                if (item.productCode.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(item.productCode,
                        style: const TextStyle(fontSize: 10.5, color: AppTheme.textGrey)),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('×${item.quantity}',
                  style: const TextStyle(color: AppTheme.textGrey, fontSize: 12)),
              const SizedBox(height: 2),
              // unitCost is what a purchase records — the price paid to the
              // supplier — not the sale price shown on the product screen.
              Text(Formatter.currency(item.unitCost * item.quantity),
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            ],
          ),
        ]),
      )).toList(),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  CREATE PURCHASE — product picker UI
//  Supplier dropdown + searchable/scannable product grid + cart flow.
// ══════════════════════════════════════════════════════════════════════════════
class _CreatePurchaseScreen extends StatefulWidget {
  const _CreatePurchaseScreen();
  @override
  State<_CreatePurchaseScreen> createState() => _CreatePurchaseState();
}

class _CreatePurchaseState extends State<_CreatePurchaseScreen> {
  SupplierModel? _supplier;
  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';
  String _selectedCategory = 'All';

  /// Cart keyed by option id (falls back to product id if an option has no
  /// id). Each entry: {productId, optionId, name, productCode, quantity, unitCost}.
  /// Keying by option — not product — means two variants of the same
  /// product (e.g. 8GB vs 16GB RAM) get separate cart lines with their own
  /// cost and code, instead of overwriting each other.
  final Map<String, Map<String, dynamic>> _cart = {};
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SupplierProvider>().load();
      context.read<ProductProvider>().loadAll();
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  int get _cartCount =>
      _cart.values.fold(0, (sum, i) => sum + (i['quantity'] as int));

  List<ProductModel> _filteredProducts(List<ProductModel> all) {
    return all.where((p) {
      final catMatch = _selectedCategory == 'All' || p.category == _selectedCategory;
      final qMatch = _query.isEmpty ||
          p.name.toLowerCase().contains(_query.toLowerCase()) ||
          p.options.any((o) =>
              o.productCode.toLowerCase().contains(_query.toLowerCase()));
      return catMatch && qMatch;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('New Purchase'),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
      ),
      body: Consumer2<ProductProvider, SupplierProvider>(
        builder: (_, prodProv, supProv, __) {
          final products = _filteredProducts(prodProv.products);
          final categories = <String>{
            'All',
            ...prodProv.categories.map((c) => c.name),
          }.toList();

          return Column(children: [
            _PurchaseHeader(
              supplier: _supplier,
              suppliers: supProv.suppliers,
              onSupplierChanged: (v) => setState(() => _supplier = v),
              searchCtrl: _searchCtrl,
              onSearchChanged: (v) => setState(() => _query = v),
              onScan: () => _scanToSearch(context),
            ),
            _CategoryChipRow(
              categories: categories,
              selected: _selectedCategory,
              onSelect: (c) => setState(() => _selectedCategory = c),
            ),
            Expanded(
              child: prodProv.isLoading
                  ? const AppLoading()
                  : products.isEmpty
                  ? const EmptyState(
                  message: 'រកមិនឃើញផលិតផល', icon: Icons.inventory_2_outlined)
                  : GridView.builder(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10,
                  childAspectRatio: 0.72,
                ),
                itemCount: products.length,
                itemBuilder: (_, i) => _ProductPickCard(
                  product: products[i],
                  qtyInCart: _qtyForProduct(products[i]),
                  onTap: () => _onProductTap(context, products[i]),
                ),
              ),
            ),
          ]);
        },
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: Row(children: [
            _CartFab(count: _cartCount, onTap: () => _openCart(context)),
            const Spacer(),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _cart.isEmpty
                    ? AppTheme.textGrey.withOpacity(0.5)
                    : AppTheme.textGrey.withOpacity(0.9),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
              ),
              onPressed: _cart.isEmpty ? null : () => _openCart(context),
              child: const Text('Go to Cart',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _scanToSearch(BuildContext context) async {
    final code = await scanBarcode(context);
    if (code != null && code.isNotEmpty) {
      setState(() {
        _searchCtrl.text = code;
        _query = code;
      });
    }
  }

  /// Sum quantities across all of this product's options currently in cart.
  int _qtyForProduct(ProductModel p) {
    return _cart.values
        .where((i) => i['productId'] == p.id)
        .fold(0, (sum, i) => sum + (i['quantity'] as int));
  }

  /// Tapping a product card: if it has one option, add it straight away.
  /// If it has multiple (e.g. different RAM/storage), open the full-screen
  /// option picker so the right variant — with its own code/cost — goes
  /// into the cart.
  Future<void> _onProductTap(BuildContext context, ProductModel p) async {
    if (p.options.isEmpty) {
      showSnack(context, 'ផលិតផលនេះមិនមានជម្រើស', error: true);
      return;
    }
    if (p.options.length == 1) {
      _addOptionToCart(p, p.options.first);
      return;
    }
    final opt = await Navigator.push<ProductOptionModel>(
      context,
      MaterialPageRoute(builder: (_) => _OptionPickerScreen(product: p)),
    );
    if (opt != null) _addOptionToCart(p, opt);
  }

  void _addOptionToCart(ProductModel p, ProductOptionModel opt) {
    setState(() {
      final key = opt.id.isNotEmpty ? opt.id : p.id;
      final existing = _cart[key];
      _cart[key] = {
        'productId': p.id,
        'optionId': opt.id,
        'name': p.options.length > 1 ? '${p.name} (${opt.specLabel})' : p.name,
        'productCode': opt.productCode,
        'imageUrl': opt.imageUrl ?? p.imageUrl,
        'quantity': (existing?['quantity'] as int? ?? 0) + 1,
        // unitCost is what a purchase records — supplier's cost, not sale price.
        'unitCost': opt.unitCost ?? opt.price,
        // sale price kept too, so the cart can show both side by side.
        'price': opt.price,
      };
    });
    showSnack(context, '${p.name} ត្រូវបានបញ្ចូល');
  }

  Future<void> _openCart(BuildContext context) async {
    final note = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => _CartScreen(
        cart: _cart,
        onUpdate: (id, qty) => setState(() {
          if (qty <= 0) {
            _cart.remove(id);
          } else {
            _cart[id]!['quantity'] = qty;
          }
        }),
      )),
    );
    // Cart pops with `null` on plain back/cancel, and with a String
    // (possibly empty) when "Submit Purchase" was tapped — so we can tell
    // "user backed out" apart from "user submitted with no note".
    if (note != null) await _submit(context, note);
  }

  Future<void> _submit(BuildContext context, String note) async {
    if (_supplier == null || _cart.isEmpty) {
      showSnack(context, 'សូមជ្រើសរើសអ្នកផ្គត់ផ្គង់ និងបញ្ចូលធាតុមួយយ៉ាងហោចណាស់', error: true);
      return;
    }
    setState(() => _submitting = true);
    // The API expects `productCode`, `quantity`, `unitCost`, `unitPrice`
    // per item, plus a top-level optional `note`.
    final body = {
      'supplierId': _supplier!.id,
      if (note.trim().isNotEmpty) 'note': note.trim(),
      'items': _cart.values.map((i) => {
        'productCode': i['productCode'],
        'quantity': i['quantity'],
        'unitCost': i['unitCost'],
        'unitPrice': (i['price'] as num?) ?? i['unitCost'],
      }).toList(),
    };
    final ok = await context.read<PurchaseProvider>().create(body);
    if (!mounted) return;
    setState(() => _submitting = false);
    if (ok) {
      setState(() => _cart.clear());
      Navigator.pop(context);
      showSnack(context, 'បង្កើតការទិញដោយជោគជ័យ');
    } else {
      showSnack(context, 'មានបញ្ហា — សូមព្យាយាមម្ដងទៀត', error: true);
    }
  }
}

// ── Header: supplier dropdown + search + scan, one continuous brand block ─────
class _PurchaseHeader extends StatelessWidget {
  final SupplierModel? supplier;
  final List<SupplierModel> suppliers;
  final ValueChanged<SupplierModel?> onSupplierChanged;
  final TextEditingController searchCtrl;
  final ValueChanged<String> onSearchChanged;
  final VoidCallback onScan;

  const _PurchaseHeader({
    required this.supplier,
    required this.suppliers,
    required this.onSupplierChanged,
    required this.searchCtrl,
    required this.onSearchChanged,
    required this.onScan,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: AppTheme.primary,
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
      child: Column(children: [
        // Supplier row
        Row(children: [
          const Text('Supplier :',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButtonFormField<SupplierModel>(
                  value: supplier,
                  isExpanded: true,
                  icon: const Icon(Icons.keyboard_arrow_down, color: AppTheme.textGrey),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.people_alt_outlined,
                        color: AppTheme.textGrey, size: 20),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 8),
                  ),
                  hint: const Text('ជ្រើសរើសអ្នកផ្គត់ផ្គង់',
                      style: TextStyle(fontSize: 13, color: AppTheme.textGrey)),
                  items: suppliers.map((s) => DropdownMenuItem(
                      value: s, child: Text(s.name, style: const TextStyle(fontSize: 13)))).toList(),
                  onChanged: onSupplierChanged,
                ),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        // Search row
        Row(children: [
          Expanded(
            child: Container(
              height: 46,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: searchCtrl,
                onChanged: onSearchChanged,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'Search',
                  hintStyle: const TextStyle(color: AppTheme.textGrey),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.qr_code_scanner, color: AppTheme.primary),
                    tooltip: 'ស្កេនកូដ',
                    onPressed: onScan,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 46, height: 46,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            child: IconButton(
              icon: const Icon(Icons.search, color: AppTheme.primary),
              tooltip: 'ស្វែងរក',
              onPressed: () => FocusScope.of(context).unfocus(),
            ),
          ),
        ]),
      ]),
    );
  }
}

// ── Category filter chip row ────────────────────────────────────────────────
class _CategoryChipRow extends StatelessWidget {
  final List<String> categories;
  final String selected;
  final ValueChanged<String> onSelect;
  const _CategoryChipRow({
    required this.categories, required this.selected, required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: SizedBox(
        height: 38,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          itemCount: categories.length,
          itemBuilder: (_, i) {
            final c = categories[i];
            final sel = selected == c;
            return GestureDetector(
              onTap: () => onSelect(c),
              child: Container(
                margin: const EdgeInsets.only(right: 8),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                decoration: BoxDecoration(
                  color: sel ? AppTheme.primary : const Color(0xFFF3F3F3),
                  borderRadius: BorderRadius.circular(20),
                ),
                alignment: Alignment.center,
                child: Text(c, style: TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600,
                    color: sel ? Colors.white : AppTheme.textDark)),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ── Product card in the picker grid ───────────────────────────────────────────
class _ProductPickCard extends StatelessWidget {
  final ProductModel product;
  final int qtyInCart;
  final VoidCallback onTap;
  const _ProductPickCard({
    required this.product, required this.qtyInCart, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cost = product.unitCost ?? product.price;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.primary.withOpacity(0.35)),
        ),
        child: Stack(children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(9)),
                child: SizedBox.expand(child: _PurchaseProdImg(url: product.imageUrl)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(product.name,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                        color: AppTheme.textDark),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Text('Cost:  ${Formatter.currency(cost)}',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold,
                        color: AppTheme.primary)),
              ]),
            ),
          ]),
          if (qtyInCart > 0)
            Positioned(
              top: 6, right: 6,
              child: Container(
                width: 20, height: 20,
                decoration: const BoxDecoration(color: AppTheme.primary, shape: BoxShape.circle),
                alignment: Alignment.center,
                child: Text('$qtyInCart',
                    style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            ),
          if (product.options.length > 1)
            Positioned(
              top: 6, left: 6,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                    color: Colors.black54, borderRadius: BorderRadius.circular(5)),
                child: Text('${product.options.length} opts',
                    style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
              ),
            ),
        ]),
      ),
    );
  }
}

// ── Option picker — FULL SCREEN, shown when a tapped product has multiple
//    options. Replaces the old cramped bottom sheet so long option lists
//    (and their cost/code rows) get full vertical space and a real AppBar
//    with a search-free, scrollable list. Pops with the chosen option, or
//    null if the user backs out. ─────────────────────────────────────────
class _OptionPickerScreen extends StatelessWidget {
  final ProductModel product;
  const _OptionPickerScreen({required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: Text(product.name),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
            child: Text('ជ្រើសរើសជម្រើស (${product.options.length})',
                style: const TextStyle(fontSize: 13, color: AppTheme.textGrey)),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              itemCount: product.options.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final opt = product.options[i];
                final cost = opt.unitCost ?? opt.price;
                return InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.pop(context, opt),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: AppTheme.border),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: SizedBox(width: 58, height: 58,
                            child: _PurchaseProdImg(url: opt.imageUrl ?? product.imageUrl)),
                      ),
                      const SizedBox(width: 14),
                      Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(opt.specLabel,
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                          const SizedBox(height: 3),
                          Text(opt.productCode,
                              style: const TextStyle(fontSize: 12, color: AppTheme.textGrey)),
                        ],
                      )),
                      const SizedBox(width: 8),
                      Text('Cost: ${Formatter.currency(cost)}',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13,
                              color: AppTheme.primary)),
                      const SizedBox(width: 4),
                      const Icon(Icons.chevron_right, color: AppTheme.textGrey),
                    ]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// Image loader matching product screen's missing-image placeholder style.
class _PurchaseProdImg extends StatelessWidget {
  final String? url;
  const _PurchaseProdImg({this.url});

  static const _ph = ColoredBox(
    color: Color(0xFFF7F7F7),
    child: Center(
      child: Padding(
        padding: EdgeInsets.all(8),
        child: Icon(Icons.image_not_supported_outlined, color: Color(0xFFBBBBBB), size: 30),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final resolved = ImageHelper.resolve(url);
    if (resolved.isEmpty) return _ph;
    return Image.network(
      resolved,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => _ph,
      loadingBuilder: (_, child, prog) =>
      prog == null ? child : const ColoredBox(color: Color(0xFFF7F7F7)),
    );
  }
}

// ── Floating cart button with badge ────────────────────────────────────────────
class _CartFab extends StatelessWidget {
  final int count;
  final VoidCallback onTap;
  const _CartFab({required this.count, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(clipBehavior: Clip.none, children: [
        Container(
          width: 50, height: 50,
          decoration: BoxDecoration(
            color: const Color(0xFF9E9E9E),
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(
                color: Colors.black.withOpacity(0.15), blurRadius: 6, offset: const Offset(0, 2))],
          ),
          child: const Icon(Icons.shopping_cart_outlined, color: Colors.white),
        ),
        if (count > 0)
          Positioned(
            top: -4, right: -4,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(color: AppTheme.danger, shape: BoxShape.circle),
              constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
              child: Text('$count', textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
            ),
          ),
      ]),
    );
  }
}

// ── Cart screen (review quantities, price/cost, totals, and report) ───────────
class _CartScreen extends StatefulWidget {
  final Map<String, Map<String, dynamic>> cart;
  final void Function(String id, int qty) onUpdate;
  const _CartScreen({required this.cart, required this.onUpdate});
  @override
  State<_CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<_CartScreen> {
  bool _generating = false;
  final TextEditingController _noteCtrl = TextEditingController();

  @override
  void dispose() {
    _noteCtrl.dispose();
    super.dispose();
  }

  double _lineCost(Map<String, dynamic> i) =>
      (i['unitCost'] as num).toDouble() * (i['quantity'] as int);

  double _linePrice(Map<String, dynamic> i) =>
      ((i['price'] as num?) ?? (i['unitCost'] as num)).toDouble() * (i['quantity'] as int);

  double get _totalCost =>
      widget.cart.values.fold(0.0, (sum, i) => sum + _lineCost(i));

  double get _totalPrice =>
      widget.cart.values.fold(0.0, (sum, i) => sum + _linePrice(i));

  int get _totalItems =>
      widget.cart.values.fold(0, (sum, i) => sum + (i['quantity'] as int));

  // Tap the quantity number to type an exact value, instead of only being
  // able to nudge it with +/-. Keeps the steppers too, for quick changes.
  Future<void> _editQuantity(String id, int currentQty) async {
    final ctrl = TextEditingController(text: '$currentQty');
    final result = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('កែចំនួន'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(
            labelText: 'ចំនួន',
            border: OutlineInputBorder(),
          ),
          onSubmitted: (v) => Navigator.pop(ctx, int.tryParse(v)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('បោះបង់'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary),
            onPressed: () => Navigator.pop(ctx, int.tryParse(ctrl.text)),
            child: const Text('យល់ព្រម', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (result != null && result > 0) {
      setState(() => widget.onUpdate(id, result));
    } else if (result == 0) {
      setState(() => widget.onUpdate(id, 0));
    }
  }

  @override
  Widget build(BuildContext context) {
    final entries = widget.cart.entries.toList();
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('Cart'),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: _generating
                ? const SizedBox(width: 20, height: 20,
                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.download_outlined, color: Colors.white),
            tooltip: 'ទាញយករបាយការណ៍',
            onPressed: entries.isEmpty || _generating
                ? null
                : () => _downloadReport(context),
          ),
        ],
      ),
      body: entries.isEmpty
          ? const EmptyState(message: 'រទេះទទេ', icon: Icons.shopping_cart_outlined)
          : ListView.builder(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
        itemCount: entries.length,
        itemBuilder: (_, i) {
          final id = entries[i].key;
          final item = entries[i].value;
          final qty = item['quantity'] as int;
          final unitCost = (item['unitCost'] as num).toDouble();
          final unitPrice = ((item['price'] as num?) ?? unitCost).toDouble();
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: SizedBox(width: 52, height: 52,
                      child: _PurchaseProdImg(url: item['imageUrl']?.toString())),
                ),
                const SizedBox(width: 10),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['name']?.toString() ?? '',
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                    if ((item['productCode'] as String?)?.isNotEmpty == true) ...[
                      const SizedBox(height: 2),
                      Text(item['productCode'].toString(),
                          style: const TextStyle(fontSize: 11, color: AppTheme.textGrey)),
                    ],
                    const SizedBox(height: 4),
                    // Wrap (instead of a plain Row) lets the second price
                    // tag drop to its own line instead of overflowing on
                    // narrow screens.
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        _PriceTag(label: 'Price', value: unitPrice, color: AppTheme.primary),
                        _PriceTag(label: 'Cost', value: unitCost, color: AppTheme.textGrey),
                      ],
                    ),
                  ],
                )),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Row(children: [
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.remove_circle_outline, size: 20, color: AppTheme.primary),
                      onPressed: () => setState(() => widget.onUpdate(id, qty - 1)),
                    ),
                    // Tappable quantity — opens a dialog to type an exact
                    // number instead of only nudging with +/-.
                    InkWell(
                      borderRadius: BorderRadius.circular(6),
                      onTap: () => _editQuantity(id, qty),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                        child: Text('$qty',
                            style: const TextStyle(fontWeight: FontWeight.bold,
                                decoration: TextDecoration.underline,
                                decorationStyle: TextDecorationStyle.dotted)),
                      ),
                    ),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.add_circle_outline, size: 20, color: AppTheme.primary),
                      onPressed: () => setState(() => widget.onUpdate(id, qty + 1)),
                    ),
                  ]),
                  // Explicit remove — clearer than relying on decrementing
                  // to zero, and removes the line in one tap.
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.delete_outline, size: 18, color: AppTheme.danger),
                    tooltip: 'លុបចេញពីរទេះ',
                    onPressed: () => setState(() => widget.onUpdate(id, 0)),
                  ),
                ]),
              ]),
              const Divider(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('សរុបធាតុ', style: TextStyle(fontSize: 12, color: AppTheme.textGrey)),
                  Text(Formatter.currency(unitCost * qty),
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13,
                          color: AppTheme.primary)),
                ],
              ),
            ]),
          );
        },
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, -2))],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AppField(
                controller: _noteCtrl,
                label: 'កំណត់ចំណាំ (Note) — ស្រេចចិត្ត',
                icon: Icons.notes_outlined,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('ចំនួនធាតុ ($_totalItems)',
                    style: const TextStyle(fontSize: 12, color: AppTheme.textGrey)),
                Text('តម្លៃលក់សរុប: ${Formatter.currency(_totalPrice)}',
                    style: const TextStyle(fontSize: 12, color: AppTheme.textGrey)),
              ],
            ),
            const SizedBox(height: 6),
            Row(children: [
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Total Cost', style: TextStyle(fontSize: 12, color: AppTheme.textGrey)),
                  Text(Formatter.currency(_totalCost),
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.primary)),
                ],
              )),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primary,
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                ),
                // Pops the note text (possibly empty) instead of `true` —
                // the caller tells "submitted" apart from "cancelled" by
                // null-checking the result.
                onPressed: entries.isEmpty ? null : () => Navigator.pop(context, _noteCtrl.text),
                child: const Text('Submit Purchase',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  Future<void> _downloadReport(BuildContext context) async {
    setState(() => _generating = true);
    try {
      final bytes = await _buildReportPdf();
      if (!mounted) return;
      await Printing.sharePdf(
        bytes: bytes,
        filename: 'purchase_order_${DateTime.now().millisecondsSinceEpoch}.pdf',
      );
    } catch (_) {
      if (mounted) showSnack(context, 'មិនអាចបង្កើតរបាយការណ៍បានទេ', error: true);
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<Uint8List> _buildReportPdf() async {
    final doc = pw.Document();
    final entries = widget.cart.entries.toList();
    final now = DateTime.now();

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (ctx) => [
          pw.Text('Purchase Order Report',
              style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          pw.Text('Generated: ${Formatter.date(now)}',
              style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
          pw.SizedBox(height: 16),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
            columnWidths: const {
              0: pw.FlexColumnWidth(3),
              1: pw.FlexColumnWidth(1.4),
              2: pw.FlexColumnWidth(1),
              3: pw.FlexColumnWidth(1.4),
              4: pw.FlexColumnWidth(1.4),
              5: pw.FlexColumnWidth(1.6),
            },
            children: [
              pw.TableRow(
                decoration: const pw.BoxDecoration(color: PdfColors.grey200),
                children: [
                  _pdfCell('Product', bold: true),
                  _pdfCell('Code', bold: true),
                  _pdfCell('Qty', bold: true),
                  _pdfCell('Cost', bold: true),
                  _pdfCell('Price', bold: true),
                  _pdfCell('Subtotal', bold: true),
                ],
              ),
              for (final e in entries)
                pw.TableRow(children: [
                  _pdfCell(e.value['name']?.toString() ?? ''),
                  _pdfCell(e.value['productCode']?.toString() ?? ''),
                  _pdfCell('${e.value['quantity']}'),
                  _pdfCell(Formatter.currency((e.value['unitCost'] as num).toDouble())),
                  _pdfCell(Formatter.currency(((e.value['price'] as num?) ?? (e.value['unitCost'] as num)).toDouble())),
                  _pdfCell(Formatter.currency(_lineCost(e.value))),
                ]),
            ],
          ),
          pw.SizedBox(height: 16),
          pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
              pw.Text('Total Items: $_totalItems', style: const pw.TextStyle(fontSize: 11)),
              pw.SizedBox(height: 2),
              pw.Text('Total Sale Value: ${Formatter.currency(_totalPrice)}',
                  style: const pw.TextStyle(fontSize: 11)),
              pw.SizedBox(height: 2),
              pw.Text('Total Cost: ${Formatter.currency(_totalCost)}',
                  style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
            ]),
          ),
        ],
      ),
    );

    return doc.save();
  }

  pw.Widget _pdfCell(String text, {bool bold = false}) => pw.Padding(
    padding: const pw.EdgeInsets.all(6),
    child: pw.Text(text,
        style: pw.TextStyle(
            fontSize: 9.5,
            fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
  );
}

// ── Small price/cost label chip used in cart rows ──────────────────────────────
class _PriceTag extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  const _PriceTag({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text('$label: ${Formatter.currency(value)}',
          style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: color)),
    );
  }
}


// ══════════════════════════════════════════════════════════════════════════════
//  PURCHASE REPORT SCREEN
// ══════════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════════
//  PURCHASE REPORT MODAL — 4 report types with download/print buttons
//  Matches PDF reference layouts exactly (see pos_report_helper.dart)
// ══════════════════════════════════════════════════════════════════════════════
class _PurchaseReportModal extends StatefulWidget {
  const _PurchaseReportModal({super.key});
  @override
  State<_PurchaseReportModal> createState() => _PurchaseReportModalState();
}

class _PurchaseReportModalState extends State<_PurchaseReportModal> {
  DateTime _from = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime _to   = DateTime.now();
  bool _loading  = false;

  // Which report button is loading (null = none)
  String? _activeReport;

  String _fmt(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _shortDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  Future<void> _pickRange() async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      initialDateRange: DateTimeRange(start: _from, end: _to),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(
            primary: AppTheme.primary, onPrimary: Colors.white, surface: Colors.white,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) setState(() { _from = picked.start; _to = picked.end; });
  }

  /// Loads purchases from the API for the selected date range,
  /// then generates and shares the PDF in the requested [mode].
  Future<void> _download(String mode) async {
    setState(() { _activeReport = mode; _loading = true; });
    try {
      final res = await ApiService.getPurchases(page: 0, size: 200);
      final rawList = ApiService.extractList(res);

      // Filter by date range locally (API may not support date params)
      final all = rawList
          .map((e) => PurchaseModel.fromMap(e as Map<String, dynamic>))
          .where((p) =>
              !p.createdAt.isBefore(_from) &&
              !p.createdAt.isAfter(_to.add(const Duration(days: 1))))
          .toList();

      // For each purchase, lazily load items if the list didn't include them
      final withItems = <PurchaseModel>[];
      for (final p in all) {
        if (p.items.isEmpty) {
          final detail = await context.read<PurchaseProvider>().fetchDetail(p.id);
          withItems.add(detail ?? p);
        } else {
          withItems.add(p);
        }
      }

      if (!mounted) return;
      await printPurchaseReport(
        context: context,
        mode: mode,
        purchases: withItems,
        from: _from,
        to: _to,
      );
    } catch (e) {
      if (mounted) showSnack(context, 'មិនអាចបង្កើត PDF: $e', error: true);
    } finally {
      if (mounted) setState(() { _activeReport = null; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('របាយការណ៍ការទិញ'),
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // ── Date range picker ─────────────────────────────────────────
          GestureDetector(
            onTap: _loading ? null : _pickRange,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.border),
              ),
              child: Row(children: [
                const Icon(Icons.date_range_outlined, size: 18, color: AppTheme.primary),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('ជ្រើសរើសកាលបរិច្ឆេទ',
                      style: TextStyle(fontSize: 11, color: AppTheme.textGrey)),
                  const SizedBox(height: 2),
                  Text(
                    '${_shortDate(_from)}  →  ${_shortDate(_to)}',
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700,
                        color: AppTheme.textDark),
                  ),
                ])),
                const Icon(Icons.keyboard_arrow_down_rounded, color: AppTheme.textGrey),
              ]),
            ),
          ),
          const SizedBox(height: 20),

          // ── Section label ─────────────────────────────────────────────
          const Text('ជ្រើសរើសប្រភេទរបាយការណ៍',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold,
                  color: AppTheme.textDark)),
          const SizedBox(height: 12),

          // ── 4 Report Cards ────────────────────────────────────────────
          _ReportCard(
            icon: Icons.list_alt_outlined,
            title: 'បញ្ជីការទិញ',
            subtitle: 'ទំនិញទាំងអស់ក្នុងរបាយការណ៍ស្តុក',
            color: const Color(0xFF1565C0),
            isLoading: _activeReport == 'listing',
            disabled: _loading,
            onDownload: () => _download('listing'),
          ),
          const SizedBox(height: 10),

          _ReportCard(
            icon: Icons.receipt_long_outlined,
            title: 'តាមវិក្កយបត្រ',
            subtitle: 'ចាត់ក្រុមតាមលេខបញ្ជាទិញ (INV-XXXXXX)',
            color: AppTheme.primary,
            isLoading: _activeReport == 'byInvoice',
            disabled: _loading,
            onDownload: () => _download('byInvoice'),
          ),
          const SizedBox(height: 10),

          _ReportCard(
            icon: Icons.calendar_today_outlined,
            title: 'តាមកាលបរិច្ឆេទ',
            subtitle: 'ចាត់ក្រុមតាមថ្ងៃទិញ',
            color: const Color(0xFF2E7D32),
            isLoading: _activeReport == 'byDate',
            disabled: _loading,
            onDownload: () => _download('byDate'),
          ),
          const SizedBox(height: 10),

          _ReportCard(
            icon: Icons.local_shipping_outlined,
            title: 'តាមអ្នកផ្គត់ផ្គង់',
            subtitle: 'ចាត់ក្រុមតាមឈ្មោះអ្នកផ្គត់ផ្គង់',
            color: const Color(0xFFE65100),
            isLoading: _activeReport == 'bySupplier',
            disabled: _loading,
            onDownload: () => _download('bySupplier'),
          ),

          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.infoLt,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Row(children: [
              Icon(Icons.info_outline, color: AppTheme.info, size: 16),
              SizedBox(width: 8),
              Expanded(child: Text(
                'PDF នឹងត្រូវបង្ហាញក្នុង Print Dialog ។ ចុច Share ដើម្បីរក្សាទុក ឬផ្ញើ។',
                style: TextStyle(fontSize: 11, color: AppTheme.info),
              )),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ── Report card widget ─────────────────────────────────────────────────────────
class _ReportCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final bool isLoading;
  final bool disabled;
  final VoidCallback onDownload;

  const _ReportCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.isLoading,
    required this.disabled,
    required this.onDownload,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLoading ? color : AppTheme.border,
            width: isLoading ? 1.5 : 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 6, offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: disabled ? null : onDownload,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              // Icon circle
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: isLoading
                    ? Padding(
                        padding: const EdgeInsets.all(12),
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: color,
                        ),
                      )
                    : Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 14),

              // Text
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w700,
                          color: disabled ? AppTheme.textGrey : AppTheme.textDark)),
                  const SizedBox(height: 3),
                  Text(subtitle,
                      style: const TextStyle(fontSize: 11, color: AppTheme.textGrey)),
                ],
              )),

              // Download button
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: disabled ? const Color(0xFFF0F0F0) : color.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: disabled ? AppTheme.border : color.withOpacity(0.3)),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(
                    isLoading ? Icons.hourglass_empty_rounded : Icons.download_outlined,
                    size: 14,
                    color: disabled ? AppTheme.textGrey : color,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    isLoading ? 'កំពុង...' : 'PDF',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: disabled ? AppTheme.textGrey : color),
                  ),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// Small widgets used by _PurchaseReportModal (kept for compat)
class _HeroChip extends StatelessWidget {
  final String text;
  const _HeroChip(this.text);
  @override
  Widget build(_) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(8),
    ),
    child: Text(text, style: const TextStyle(
        fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600)),
  );
}

class _StatBox extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const _StatBox({required this.label, required this.value,
      required this.icon, required this.color});
  @override
  Widget build(_) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(12),
    ),
    child: Row(children: [
      Icon(icon, color: color, size: 22),
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.textGrey)),
        Text(value, style: TextStyle(
            fontSize: 15, fontWeight: FontWeight.w700, color: color)),
      ]),
    ]),
  );
}
