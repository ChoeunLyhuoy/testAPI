// lib/models/customer_model.dart
// Matches CustomerResponse: { id, firstName, lastName, userName, email,
//   phoneNumber, password, address, role }

class CustomerModel {
  final String id;
  final String firstName;
  final String lastName;
  final String userName;
  final String email;
  final String phone;
  final String? address;

  const CustomerModel({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.userName,
    required this.email,
    required this.phone,
    this.address,
  });

  factory CustomerModel.fromMap(Map<String, dynamic> m) => CustomerModel(
        id: m['id']?.toString() ?? '',
        firstName: m['firstName']?.toString() ?? '',
        lastName: m['lastName']?.toString() ?? '',
        userName: m['userName']?.toString() ?? '',
        email: m['email']?.toString() ?? '',
        phone: m['phoneNumber']?.toString() ?? m['phone']?.toString() ?? '',
        address: m['address']?.toString(),
      );

  String get fullName => '$firstName $lastName'.trim();
  String get initials {
    final f = firstName.isNotEmpty ? firstName[0] : '';
    final l = lastName.isNotEmpty ? lastName[0] : '';
    return (f + l).toUpperCase().isNotEmpty ? (f + l).toUpperCase() : 'C';
  }
}
