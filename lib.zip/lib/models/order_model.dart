// lib/models/order_model.dart
// Parses exactly the JSON returned by both endpoints:
//
// LIST  GET /api/v1/orders  →  data: [ { id, transactionRef, paymentName,
//   subtotalAmount, promotionDiscountAmount, extraDiscountAmount,
//   totalAmount, items: [...] } ]
//
// DETAIL GET /api/v1/orders/{id}  →  data: { same fields }

class OrderItemModel {
  final String  id;
  final int     productOptionId;
  final String  productName;          // JSON: "productName"
  final String  productCode;          // JSON: "productCode"
  final int     quantity;             // JSON: "quantity"
  final double  unitPrice;            // JSON: "unitPrice"
  final double  discountedUnitPrice;  // JSON: "discountedUnitPrice"
  final double  subTotal;             // JSON: "subTotal"
  final String? imageUrl;             // JSON: "image"
  final int?    promotionId;          // JSON: "promotionId"

  const OrderItemModel({
    required this.id,
    required this.productOptionId,
    required this.productName,
    required this.productCode,
    required this.quantity,
    required this.unitPrice,
    required this.discountedUnitPrice,
    required this.subTotal,
    this.imageUrl,
    this.promotionId,
  });

  factory OrderItemModel.fromMap(Map<String, dynamic> m) {
    return OrderItemModel(
      id:                  m['id']?.toString() ?? '',
      productOptionId:     (m['productOptionId'] as num?)?.toInt() ?? 0,
      productName:         m['productName']?.toString() ?? '',
      productCode:         m['productCode']?.toString() ?? '',
      quantity:            (m['quantity'] as num?)?.toInt() ?? 0,
      unitPrice:           (m['unitPrice'] as num?)?.toDouble() ?? 0.0,
      discountedUnitPrice: (m['discountedUnitPrice'] as num?)?.toDouble() ?? 0.0,
      subTotal:            (m['subTotal'] as num?)?.toDouble() ?? 0.0,
      imageUrl:            m['image']?.toString(),   // key is "image" not "imageUrl"
      promotionId:         (m['promotionId'] as num?)?.toInt(),
    );
  }
}

class OrderModel {
  final String  id;                          // JSON: "id"
  final String  transactionRef;              // JSON: "transactionRef"
  final int?    userId;                      // JSON: "userId"
  final int?    paymentId;                   // JSON: "paymentId"
  final String? paymentName;                 // JSON: "paymentName"
  final double  subtotalAmount;              // JSON: "subtotalAmount"
  final double  promotionDiscountAmount;     // JSON: "promotionDiscountAmount"
  final double  extraDiscountAmount;         // JSON: "extraDiscountAmount"
  final double  totalAmount;                 // JSON: "totalAmount"
  final List<OrderItemModel> items;          // JSON: "items"
  // createdAt is absent from both list AND detail in your current API
  // — kept nullable so it compiles and won't crash
  final DateTime? createdAt;

  const OrderModel({
    required this.id,
    required this.transactionRef,
    this.userId,
    this.paymentId,
    this.paymentName,
    required this.subtotalAmount,
    required this.promotionDiscountAmount,
    required this.extraDiscountAmount,
    required this.totalAmount,
    required this.items,
    this.createdAt,
  });

  factory OrderModel.fromMap(Map<String, dynamic> m) {
    // Parse optional createdAt — not in current API but keep for forward compat
    DateTime? dt;
    final rawDate = m['createdAt']?.toString();
    if (rawDate != null && rawDate.isNotEmpty) {
      try { dt = DateTime.parse(rawDate); } catch (_) {}
    }

    // Parse items array — key is "items"
    final rawItems = m['items'];
    final List<OrderItemModel> itemList = rawItems is List
        ? rawItems
        .whereType<Map<String, dynamic>>()
        .map(OrderItemModel.fromMap)
        .toList()
        : [];

    return OrderModel(
      id:                          m['id']?.toString() ?? '',
      transactionRef:              m['transactionRef']?.toString() ?? '',
      userId:                      (m['userId'] as num?)?.toInt(),
      paymentId:                   (m['paymentId'] as num?)?.toInt(),
      paymentName:                 m['paymentName']?.toString(),
      subtotalAmount:              (m['subtotalAmount'] as num?)?.toDouble() ?? 0.0,
      promotionDiscountAmount:     (m['promotionDiscountAmount'] as num?)?.toDouble() ?? 0.0,
      extraDiscountAmount:         (m['extraDiscountAmount'] as num?)?.toDouble() ?? 0.0,
      totalAmount:                 (m['totalAmount'] as num?)?.toDouble()
          ?? (m['total'] as num?)?.toDouble() ?? 0.0,
      items:                       itemList,
      createdAt:                   dt,
    );
  }

  double get discountTotal => promotionDiscountAmount + extraDiscountAmount;
}